package com.example.mvc_calificaicones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvcServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
