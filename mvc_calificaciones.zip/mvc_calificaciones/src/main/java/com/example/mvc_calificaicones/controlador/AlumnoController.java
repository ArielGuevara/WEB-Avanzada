package com.example.mvc_calificaicones.controlador;

import com.example.mvc_calificaicones.modelo.Alumno;
import com.example.mvc_calificaicones.servicio.AlumnoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/api/alumnos")
public class AlumnoController {
    private final AlumnoService alumnoService;

    @Autowired
    public AlumnoController(AlumnoService alumnoService) {
        this.alumnoService = alumnoService;
    }

    @GetMapping("/obtener")
    public String visualizarAlumnos(Model model){

        model.addAttribute("alumnos", alumnoService.obtenerTodos());
        return "alumnos";
    }

    @GetMapping
    public List<Alumno> obtenerTodos() {
        return alumnoService.obtenerTodos();
    }

    @GetMapping("/{id}")
    public Alumno obtenerPorId(@PathVariable int id) {
        return alumnoService.obtenerPorId(id);
    }

    @GetMapping("/insertar")
    public String mostrarFormularioInsertar() {
        return "insertar_alumnos";}

    @PostMapping("/insertar")
    public String agregarAlumno(@RequestParam String nombre,
                              @RequestParam double nota) {
      Alumno objes =  new Alumno(1, nombre, nota);

        alumnoService.agregarAlumno(objes);
        return "redirect:/api/alumnos/obtener";
    }

    @PutMapping("/{id}")
    public void actualizarNota(@PathVariable int id, @RequestParam double nota) {
        alumnoService.actualizarNota(id, nota);
    }

    @DeleteMapping("/{id}")
    public void eliminarAlumno(@PathVariable int id) {
        alumnoService.eliminarAlumno(id);
    }
}
