package com.example.mvc_calificaicones.servicio;

import com.example.mvc_calificaicones.modelo.Alumno;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import com.fasterxml.jackson.core.type.TypeReference;

import java.io.IOException;
import java.io.File;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


@Service
public class AlumnoService {
    private final String FILE_PATH = "C:\\Users\\Ariel\\Documentos\\ESPE\\WEB Avanzada\\TERCER PARCIAL\\SpringBoot\\alumnos.json";
    private List<Alumno> alumnos;
    private final ObjectMapper objectMapper;
    private int nextID = 1;


    public AlumnoService() {
        this.objectMapper = new ObjectMapper();
        this.alumnos = cargarDesdeArchivo();
    }

    // Cargar datos desde el archivo JSON
    private List<Alumno> cargarDesdeArchivo() {
        File file = new File(FILE_PATH);
        if (!file.exists()) {
            return new ArrayList<>();
        }
        try {
            return objectMapper.readValue(file, new TypeReference<List<Alumno>>() {});
        } catch (IOException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    // Guardar datos en el archivo JSON
    private void guardarEnArchivo() {
        try {
            objectMapper.writeValue(new File(FILE_PATH), alumnos);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public List<Alumno> obtenerTodos() {
        return alumnos;
    }

    public Alumno obtenerPorId(int id) {
        return alumnos.stream()
                .filter(alumno -> alumno.getId() == id)
                .findFirst()
                .orElse(null);
    }

    public void agregarAlumno(Alumno alumno) {
        int idtemp=0;
        idtemp = nextID++;
        alumno.setId(idtemp);
        alumnos.add(alumno);
        guardarEnArchivo();
    }

    public void actualizarNota(int id, double nota) {
        for (Alumno alumno : alumnos) {
            if (alumno.getId() == id) {
                alumno.setNota(nota);
                guardarEnArchivo();
                break;
            }
        }
    }

    public List<Alumno> obtenerOrdenadosPorNota(boolean ascendente) {
        return alumnos.stream()
                .sorted(ascendente
                        ? Comparator.comparingDouble(Alumno::getNota)
                        : Comparator.comparingDouble(Alumno::getNota).reversed())
                .collect(Collectors.toList());
    }

    public void eliminarAlumno(int id) {
        alumnos.removeIf(alumno -> alumno.getId() == id);
        guardarEnArchivo();
    }
}