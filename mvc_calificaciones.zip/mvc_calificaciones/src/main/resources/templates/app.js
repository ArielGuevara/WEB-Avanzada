function orderPorNota(){
    //var nota =
}